import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';

export default function Login({ onLogin }) {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [newName, setNewName] = useState('');
  const [adding, setAdding] = useState(false);

  useEffect(() => { fetchUsers(); }, []);

  const fetchUsers = async () => {
    const { data } = await supabase.from('users').select('*').order('role').order('name');
    setUsers(data || []);
    setLoading(false);
  };

  const addSender = async () => {
    if (!newName.trim()) return;
    const { data } = await supabase.from('users').insert({ name: newName.trim(), role: 'sender' }).select().single();
    if (data) { setUsers(p => [...p, data]); setNewName(''); setAdding(false); }
  };

  const drivers = users.filter(u => u.role === 'driver');
  const senders = users.filter(u => u.role === 'sender');

  return (
    <div style={s.wrap}>
      <style>{fonts}</style>
      <div style={s.card}>
        <div style={{ fontSize:'44px', textAlign:'center', marginBottom:'10px' }}>🔧</div>
        <h1 style={s.title}>מוסך – ניהול נהגים</h1>
        <p style={s.sub}>בחר את המשתמש שלך</p>

        {loading ? <p style={{ color:'#64748B', textAlign:'center' }}>טוען...</p> : <>
          <Section label="נהגים 🚗">
            {drivers.map(u => <UserBtn key={u.id} user={u} onClick={() => onLogin(u)} accent="#3B82F6" />)}
          </Section>
          <Section label="שולחים 📋">
            {senders.map(u => <UserBtn key={u.id} user={u} onClick={() => onLogin(u)} accent="#8B5CF6" />)}
            {adding
              ? <div style={{ display:'flex', gap:'8px', marginTop:'8px' }}>
                  <input value={newName} onChange={e=>setNewName(e.target.value)} placeholder="שם מלא..." onKeyDown={e=>e.key==='Enter'&&addSender()} style={s.input} autoFocus />
                  <button onClick={addSender} style={s.btnAdd}>הוסף</button>
                  <button onClick={()=>setAdding(false)} style={s.btnCancel}>ביטול</button>
                </div>
              : <button onClick={()=>setAdding(true)} style={s.btnDashed}>+ הוסף שולח חדש</button>
            }
          </Section>
        </>}
      </div>
    </div>
  );
}

function Section({ label, children }) {
  return (
    <div style={{ marginBottom:'22px' }}>
      <p style={{ color:'#64748B', fontSize:'11px', fontWeight:'700', letterSpacing:'1px', textTransform:'uppercase', marginBottom:'8px' }}>{label}</p>
      {children}
    </div>
  );
}

function UserBtn({ user, onClick, accent }) {
  return (
    <button onClick={onClick} style={{ width:'100%', padding:'13px 16px', background:'rgba(255,255,255,0.04)', border:'1px solid rgba(255,255,255,0.07)', borderRadius:'12px', color:'white', fontSize:'15px', fontWeight:'600', cursor:'pointer', textAlign:'right', marginBottom:'7px', display:'flex', alignItems:'center', gap:'10px', fontFamily:'Heebo,sans-serif' }}>
      <div style={{ width:'34px', height:'34px', borderRadius:'50%', background:accent, display:'flex', alignItems:'center', justifyContent:'center', fontWeight:'700', fontSize:'15px', flexShrink:0 }}>{user.name[0]}</div>
      {user.name}
      {user.is_backup && <span style={{ marginRight:'auto', fontSize:'11px', color:'#64748B', background:'rgba(255,255,255,0.05)', padding:'2px 7px', borderRadius:'10px' }}>גיבוי</span>}
    </button>
  );
}

const fonts = `@import url('https://fonts.googleapis.com/css2?family=Heebo:wght@400;600;700;800&display=swap'); *{box-sizing:border-box;margin:0;padding:0;}`;
const s = {
  wrap:      { minHeight:'100vh', background:'#0F172A', display:'flex', alignItems:'center', justifyContent:'center', padding:'24px', fontFamily:'Heebo,sans-serif', direction:'rtl' },
  card:      { width:'100%', maxWidth:'390px', background:'#1E293B', borderRadius:'24px', padding:'30px', border:'1px solid rgba(255,255,255,0.07)' },
  title:     { color:'white', fontSize:'20px', fontWeight:'800', textAlign:'center', marginBottom:'4px' },
  sub:       { color:'#64748B', fontSize:'14px', textAlign:'center', marginBottom:'26px' },
  input:     { flex:1, padding:'10px 12px', background:'rgba(255,255,255,0.06)', border:'1px solid rgba(255,255,255,0.1)', borderRadius:'10px', color:'white', fontSize:'14px', fontFamily:'Heebo,sans-serif', direction:'rtl', outline:'none' },
  btnAdd:    { padding:'10px 14px', background:'#3B82F6', border:'none', borderRadius:'10px', color:'white', fontSize:'14px', fontWeight:'600', cursor:'pointer', fontFamily:'Heebo,sans-serif', whiteSpace:'nowrap' },
  btnCancel: { padding:'10px 14px', background:'rgba(255,255,255,0.06)', border:'none', borderRadius:'10px', color:'#94A3B8', fontSize:'14px', cursor:'pointer', fontFamily:'Heebo,sans-serif', whiteSpace:'nowrap' },
  btnDashed: { width:'100%', padding:'11px', background:'transparent', border:'1px dashed rgba(255,255,255,0.12)', borderRadius:'12px', color:'#64748B', fontSize:'13px', cursor:'pointer', fontFamily:'Heebo,sans-serif', marginTop:'4px' },
};
