import { useState, useEffect } from 'react';
import { supabase, TASK_TYPES, STATUS, formatTime, timeDiff } from '../lib/supabase';
import NewTaskModal from '../components/NewTaskModal';

export default function DriverView({ user, onLogout }) {
  const [tasks, setTasks]     = useState([]);
  const [showNew, setShowNew] = useState(false);
  const [drivers, setDrivers] = useState([]);
  const [tab, setTab]         = useState('mine'); // mine | all

  useEffect(() => {
    fetchAll();
    if ('Notification' in window) Notification.requestPermission();
    const ch = supabase.channel(`driver-${user.id}`)
      .on('postgres_changes', { event:'*', schema:'public', table:'tasks' }, fetchAll)
      .subscribe();
    return () => supabase.removeChannel(ch);
  }, []);

  const fetchAll = async () => {
    const today = new Date().toISOString().split('T')[0];
    const [{ data: t }, { data: d }] = await Promise.all([
      supabase.from('tasks').select('*, sender:sender_id(name), driver:driver_id(name)').gte('created_at', today).order('created_at', { ascending:false }),
      supabase.from('users').select('*').eq('role','driver'),
    ]);
    setTasks(t || []);
    setDrivers(d || []);
  };

  const myTasks      = tasks.filter(t => t.driver_id === user.id && t.status !== 'done');
  const waitingTasks = tasks.filter(t => t.status === 'waiting');
  const activeTasks  = tasks.filter(t => (t.status === 'active' || t.status === 'arrived') && t.driver_id !== user.id);

  const takeTask = async (task) => {
    await supabase.from('tasks').update({ driver_id:user.id, status:'active', taken_at:new Date().toISOString() }).eq('id', task.id);
    fetchAll();
  };

  const advance = async (task) => {
    const now = new Date().toISOString();
    let updates = {};
    if (task.status === 'active')  updates = { status:'arrived', arrived_at:now };
    if (task.status === 'arrived') updates = { status:'done',    done_at:now };
    await supabase.from('tasks').update(updates).eq('id', task.id);
    fetchAll();
  };

  return (
    <div style={s.wrap}>
      <style>{fonts}</style>

      {/* Header */}
      <div style={s.header}>
        <div style={{ display:'flex', alignItems:'center', gap:'10px' }}>
          <div style={s.avatar}>{user.name[0]}</div>
          <div>
            <p style={{ color:'white', fontWeight:'700', fontSize:'16px', margin:0 }}>{user.name}</p>
            <p style={{ color: myTasks.length > 0 ? '#F59E0B' : '#10B981', fontSize:'12px', margin:0 }}>
              {myTasks.length > 0 ? `${myTasks.length} משימות פעילות` : 'פנוי'}
            </p>
          </div>
        </div>
        <button onClick={onLogout} style={s.logoutBtn}>יציאה</button>
      </div>

      {/* Tabs */}
      <div style={s.tabsWrap}>
        <button onClick={()=>setTab('mine')} style={{ ...s.tab, ...(tab==='mine'?s.tabActive:{}) }}>
          שלי {myTasks.length > 0 && <span style={s.badge}>{myTasks.length}</span>}
        </button>
        <button onClick={()=>setTab('all')} style={{ ...s.tab, ...(tab==='all'?s.tabActive:{}) }}>
          ממתינות {waitingTasks.length > 0 && <span style={{ ...s.badge, background:'#6B7280' }}>{waitingTasks.length}</span>}
        </button>
      </div>

      <div style={s.content}>
        {tab === 'mine' && (
          <>
            {myTasks.length === 0
              ? <div style={s.empty}>
                  <div style={{ fontSize:'48px', marginBottom:'12px' }}>✅</div>
                  <p style={{ color:'#10B981', fontSize:'18px', fontWeight:'700' }}>אין משימות פעילות</p>
                  <p style={{ color:'#475569', fontSize:'13px', marginTop:'6px' }}>עבור ל"ממתינות" לתפוס משימה</p>
                </div>
              : myTasks.map(task => (
                <MobileTaskCard key={task.id} task={task} onAdvance={()=>advance(task)} isMine />
              ))
            }
          </>
        )}

        {tab === 'all' && (
          <>
            {waitingTasks.length === 0 && activeTasks.length === 0
              ? <div style={s.empty}>
                  <div style={{ fontSize:'40px', marginBottom:'12px' }}>🎉</div>
                  <p style={{ color:'#475569', fontSize:'15px' }}>אין משימות ממתינות</p>
                </div>
              : <>
                  {waitingTasks.length > 0 && (
                    <>
                      <p style={s.sectionLabel}>📋 ממתינות לטיפול</p>
                      {waitingTasks.map(task => (
                        <MobileTaskCard key={task.id} task={task} onTake={()=>takeTask(task)} />
                      ))}
                    </>
                  )}
                  {activeTasks.length > 0 && (
                    <>
                      <p style={{ ...s.sectionLabel, marginTop:'16px' }}>🟡 בטיפול נהגים אחרים</p>
                      {activeTasks.map(task => (
                        <MobileTaskCard key={task.id} task={task} />
                      ))}
                    </>
                  )}
                </>
            }
          </>
        )}

        <button onClick={()=>setShowNew(true)} style={s.newBtn}>+ משימה חדשה</button>
      </div>

      {showNew && <NewTaskModal user={user} drivers={drivers} onClose={()=>setShowNew(false)} onCreated={fetchAll} />}
    </div>
  );
}

function MobileTaskCard({ task, onTake, onAdvance, isMine }) {
  const cfg  = STATUS[task.status] || STATUS.waiting;
  const type = TASK_TYPES[task.type] || {};

  const btnLabel = {
    active:  '📍 הגעתי ליעד',
    arrived: '✅ סיימתי',
  }[task.status];

  return (
    <div style={{ background:'#1E293B', borderRadius:'18px', padding:'18px', marginBottom:'12px', border:`1px solid ${task.status==='active'?'rgba(245,158,11,0.3)':task.status==='arrived'?'rgba(59,130,246,0.3)':'rgba(255,255,255,0.06)'}` }}>
      <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:'12px' }}>
        <div style={{ display:'flex', alignItems:'center', gap:'8px' }}>
          <span style={{ fontSize:'20px' }}>{type.icon}</span>
          <span style={{ color:'white', fontWeight:'700', fontSize:'16px' }}>{type.label}</span>
        </div>
        <div style={{ background:cfg.bg, color:cfg.color, padding:'3px 10px', borderRadius:'20px', fontSize:'12px', fontWeight:'600' }}>{cfg.label}</div>
      </div>

      {task.client_name    && <p style={s.det}>👤 {task.client_name}</p>}
      {task.client_address && <p style={s.det}>📍 {task.client_address}</p>}
      {task.car_plate      && <p style={{ ...s.det, fontFamily:'monospace' }}>🚗 {task.car_plate}</p>}
      {task.car_plate2     && <p style={{ ...s.det, fontFamily:'monospace', color:'#F59E0B' }}>🅿️ רכב מוסך: {task.car_plate2}</p>}
      {task.lexus_direction && <p style={s.det}>🔄 {task.lexus_direction==='from_lexus'?'מלקסוס → מוסך':'מוסך → לקסוס'}</p>}
      {task.small_description && <p style={s.det}>📝 {task.small_description}</p>}
      {task.driver         && <p style={{ ...s.det, color:'#3B82F6' }}>🧑‍✈️ {task.driver.name}</p>}
      {task.sender         && <p style={{ ...s.det, color:'#475569', fontSize:'11px' }}>נפתחה ע"י: {task.sender.name}</p>}

      {/* Times */}
      <div style={{ display:'flex', gap:'5px', flexWrap:'wrap', marginTop:'10px', marginBottom:'4px' }}>
        <MiniChip label="נפתחה" time={formatTime(task.opened_at)} color="#6B7280" />
        {task.taken_at   && <MiniChip label="התחיל"  time={formatTime(task.taken_at)}   color="#F59E0B" />}
        {task.arrived_at && <MiniChip label="הגיע"   time={formatTime(task.arrived_at)} color="#3B82F6" />}
        {task.done_at    && <MiniChip label="סיים"   time={formatTime(task.done_at)}    color="#10B981" />}
        {task.done_at    && <MiniChip label="⏱️"      time={timeDiff(task.opened_at,task.done_at)} color="#8B5CF6" />}
      </div>

      {onTake && (
        <button onClick={onTake} style={{ ...s.actionBtn, background:'linear-gradient(135deg,#3B82F6,#8B5CF6)', marginTop:'12px' }}>
          ✋ אני לוקח
        </button>
      )}
      {onAdvance && isMine && (task.status==='active'||task.status==='arrived') && (
        <button onClick={onAdvance} style={{ ...s.actionBtn, background: task.status==='arrived'?'linear-gradient(135deg,#10B981,#059669)':'linear-gradient(135deg,#F59E0B,#D97706)', marginTop:'12px' }}>
          {btnLabel}
        </button>
      )}
    </div>
  );
}

function MiniChip({ label, time, color }) {
  if (!time) return null;
  return (
    <div style={{ display:'flex', flexDirection:'column', alignItems:'center', background:'rgba(255,255,255,0.05)', borderRadius:'7px', padding:'3px 7px' }}>
      <span style={{ color:'#475569', fontSize:'9px' }}>{label}</span>
      <span style={{ color, fontSize:'11px', fontWeight:'700', fontFamily:'monospace' }}>{time}</span>
    </div>
  );
}

const fonts = `@import url('https://fonts.googleapis.com/css2?family=Heebo:wght@400;600;700;800&display=swap'); *{box-sizing:border-box;margin:0;padding:0;}`;
const s = {
  wrap:       { minHeight:'100vh', background:'#0F172A', fontFamily:'Heebo,sans-serif', direction:'rtl' },
  header:     { background:'#1E293B', padding:'14px 18px', display:'flex', alignItems:'center', justifyContent:'space-between', borderBottom:'1px solid rgba(255,255,255,0.06)', position:'sticky', top:0, zIndex:50 },
  avatar:     { width:'42px', height:'42px', borderRadius:'50%', background:'linear-gradient(135deg,#3B82F6,#8B5CF6)', display:'flex', alignItems:'center', justifyContent:'center', fontWeight:'700', color:'white', fontSize:'17px', flexShrink:0 },
  logoutBtn:  { background:'rgba(255,255,255,0.06)', border:'none', color:'#64748B', padding:'7px 13px', borderRadius:'9px', cursor:'pointer', fontSize:'12px', fontFamily:'Heebo,sans-serif' },
  tabsWrap:   { display:'flex', background:'#1E293B', borderBottom:'1px solid rgba(255,255,255,0.06)', padding:'0 18px' },
  tab:        { flex:1, padding:'12px', background:'transparent', border:'none', color:'#64748B', fontSize:'14px', fontWeight:'600', cursor:'pointer', borderBottom:'2px solid transparent', fontFamily:'Heebo,sans-serif', display:'flex', alignItems:'center', justifyContent:'center', gap:'6px' },
  tabActive:  { color:'#3B82F6', borderBottom:'2px solid #3B82F6' },
  badge:      { background:'#F59E0B', color:'white', fontSize:'10px', fontWeight:'700', padding:'1px 6px', borderRadius:'10px' },
  content:    { padding:'16px', maxWidth:'480px', margin:'0 auto' },
  empty:      { textAlign:'center', padding:'48px 24px' },
  sectionLabel:{ color:'#64748B', fontSize:'12px', fontWeight:'700', textTransform:'uppercase', letterSpacing:'1px', marginBottom:'10px' },
  det:        { color:'#94A3B8', fontSize:'13px', marginBottom:'4px' },
  actionBtn:  { width:'100%', padding:'13px', border:'none', borderRadius:'12px', color:'white', fontSize:'15px', fontWeight:'700', cursor:'pointer', fontFamily:'Heebo,sans-serif' },
  newBtn:     { width:'100%', padding:'14px', background:'linear-gradient(135deg,#3B82F6,#8B5CF6)', border:'none', borderRadius:'14px', color:'white', fontSize:'15px', fontWeight:'700', cursor:'pointer', fontFamily:'Heebo,sans-serif', marginTop:'8px' },
};
