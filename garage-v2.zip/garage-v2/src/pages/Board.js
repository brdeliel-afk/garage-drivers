import { useState, useEffect } from 'react';
import { supabase, TASK_TYPES, STATUS, formatTime, timeDiff } from '../lib/supabase';
import NewTaskModal from '../components/NewTaskModal';
import TaskCard from '../components/TaskCard';
import GarageCars from '../components/GarageCars';

const COLS = [
  { key:'waiting', label:'📋 ממתינות' },
  { key:'active',  label:'🟡 בביצוע'  },
  { key:'arrived', label:'📍 הגיע ליעד' },
  { key:'done',    label:'✅ הושלמו'  },
];

export default function Board({ user, onLogout }) {
  const [tasks, setTasks]         = useState([]);
  const [tab, setTab]             = useState('board'); // board | history | cars
  const [showNew, setShowNew]     = useState(false);
  const [drivers, setDrivers]     = useState([]);

  useEffect(() => {
    fetchAll();
    const ch = supabase.channel('board')
      .on('postgres_changes', { event:'*', schema:'public', table:'tasks' }, fetchAll)
      .subscribe();
    return () => supabase.removeChannel(ch);
  }, []);

  const fetchAll = async () => {
    const [{ data: t }, { data: d }] = await Promise.all([
      supabase.from('tasks').select('*, sender:sender_id(name), driver:driver_id(name), driver2:driver2_id(name)').order('created_at', { ascending: false }),
      supabase.from('users').select('*').eq('role','driver').order('name'),
    ]);
    setTasks(t || []);
    setDrivers(d || []);
  };

  const today = new Date().toISOString().split('T')[0];
  const todayTasks = tasks.filter(t => t.created_at?.startsWith(today));
  const boardTasks = todayTasks.filter(t => t.status !== 'done');
  const doneTasks  = todayTasks.filter(t => t.status === 'done');

  return (
    <div style={s.wrap}>
      <style>{fonts}</style>

      {/* Header */}
      <div style={s.header}>
        <div style={s.headerInner}>
          <div style={{ display:'flex', alignItems:'center', gap:'8px' }}>
            <span style={{ fontSize:'20px' }}>🔧</span>
            <span style={{ color:'white', fontWeight:'800', fontSize:'15px' }}>מוסך נהגים</span>
          </div>
          <div style={{ display:'flex', alignItems:'center', gap:'10px' }}>
            <span style={{ color:'#64748B', fontSize:'13px' }}>{user.name}</span>
            <button onClick={onLogout} style={s.logoutBtn}>יציאה</button>
          </div>
        </div>
        <div style={s.tabs}>
          {[['board','לוח משימות'],['history','היסטוריה'],['cars','רכבים']].map(([id,label])=>(
            <button key={id} onClick={()=>setTab(id)} style={{ ...s.tab, ...(tab===id?s.tabActive:{}) }}>{label}</button>
          ))}
        </div>
      </div>

      <div style={s.content}>
        {tab === 'board' && <>
          {/* Stats strip */}
          <div style={s.statsRow}>
            {[
              { label:'פתוחות', value: boardTasks.filter(t=>t.status==='waiting').length, color:'#6B7280' },
              { label:'בביצוע', value: boardTasks.filter(t=>t.status==='active'||t.status==='arrived').length, color:'#F59E0B' },
              { label:'הושלמו היום', value: doneTasks.length, color:'#10B981' },
            ].map(st=>(
              <div key={st.label} style={s.statCard}>
                <p style={{ color:st.color, fontSize:'26px', fontWeight:'800', margin:0 }}>{st.value}</p>
                <p style={{ color:'#64748B', fontSize:'11px', margin:0 }}>{st.label}</p>
              </div>
            ))}
          </div>

          {/* Columns */}
          <div style={s.cols}>
            {COLS.filter(c=>c.key!=='done').map(col => {
              const colTasks = boardTasks.filter(t=>t.status===col.key);
              return (
                <div key={col.key} style={s.col}>
                  <div style={s.colHeader}>
                    <span style={{ color:'#94A3B8', fontSize:'13px', fontWeight:'700' }}>{col.label}</span>
                    <span style={{ background:'rgba(255,255,255,0.08)', color:'#64748B', fontSize:'12px', padding:'1px 8px', borderRadius:'10px' }}>{colTasks.length}</span>
                  </div>
                  <div style={{ display:'flex', flexDirection:'column', gap:'10px' }}>
                    {colTasks.length === 0
                      ? <div style={s.empty}>ריק</div>
                      : colTasks.map(t=>(
                          <TaskCard key={t.id} task={t} drivers={drivers} currentUser={user} onUpdate={fetchAll} />
                        ))
                    }
                  </div>
                </div>
              );
            })}
          </div>

          {/* New task button */}
          <button onClick={()=>setShowNew(true)} style={s.newBtn}>+ משימה חדשה</button>
        </>}

        {tab === 'history' && (
          <div style={s.histCard}>
            <p style={s.histTitle}>היסטוריה – היום ({todayTasks.length} משימות)</p>
            {todayTasks.length === 0
              ? <p style={{ color:'#475569', textAlign:'center', padding:'32px' }}>אין משימות היום</p>
              : todayTasks.map(t=>(
                <div key={t.id} style={s.histRow}>
                  <div style={{ display:'flex', alignItems:'center', gap:'8px', marginBottom:'6px' }}>
                    <span style={{ fontSize:'16px' }}>{TASK_TYPES[t.type]?.icon}</span>
                    <span style={{ color:'white', fontWeight:'700', fontSize:'14px' }}>{TASK_TYPES[t.type]?.label}</span>
                    <span style={{ ...s.statusPill, background:STATUS[t.status]?.bg, color:STATUS[t.status]?.color }}>{STATUS[t.status]?.label}</span>
                    {t.driver && <span style={{ color:'#3B82F6', fontSize:'13px', marginRight:'auto' }}>{t.driver.name}</span>}
                  </div>
                  {t.client_name && <p style={s.histDetail}>👤 {t.client_name}</p>}
                  {t.car_plate && <p style={{ ...s.histDetail, fontFamily:'monospace' }}>🚗 {t.car_plate}</p>}
                  <div style={s.timesRow}>
                    <TimeChip label="נפתחה" time={formatTime(t.opened_at)} color="#6B7280" />
                    {t.taken_at   && <TimeChip label="התחילה" time={formatTime(t.taken_at)}   color="#F59E0B" />}
                    {t.arrived_at && <TimeChip label="הגיע"   time={formatTime(t.arrived_at)} color="#3B82F6" />}
                    {t.done_at    && <TimeChip label="סיים"   time={formatTime(t.done_at)}    color="#10B981" />}
                    {t.done_at    && <TimeChip label="סה״כ"   time={timeDiff(t.opened_at, t.done_at)} color="#8B5CF6" />}
                  </div>
                  {t.sender && <p style={{ color:'#475569', fontSize:'11px', marginTop:'4px' }}>נפתחה ע"י: {t.sender.name}</p>}
                </div>
              ))
            }
          </div>
        )}

        {tab === 'cars' && <GarageCars />}
      </div>

      {showNew && <NewTaskModal user={user} drivers={drivers} onClose={()=>setShowNew(false)} onCreated={fetchAll} />}
    </div>
  );
}

function TimeChip({ label, time, color }) {
  if (!time) return null;
  return (
    <div style={{ display:'flex', flexDirection:'column', alignItems:'center', background:'rgba(255,255,255,0.04)', borderRadius:'8px', padding:'4px 8px', minWidth:'52px' }}>
      <span style={{ color:'#475569', fontSize:'10px' }}>{label}</span>
      <span style={{ color, fontSize:'12px', fontWeight:'700', fontFamily:'monospace' }}>{time}</span>
    </div>
  );
}

const fonts = `@import url('https://fonts.googleapis.com/css2?family=Heebo:wght@400;600;700;800&display=swap'); *{box-sizing:border-box;margin:0;padding:0;}`;
const s = {
  wrap:       { minHeight:'100vh', background:'#0F172A', fontFamily:'Heebo,sans-serif', direction:'rtl' },
  header:     { background:'#1E293B', borderBottom:'1px solid rgba(255,255,255,0.06)', position:'sticky', top:0, zIndex:50 },
  headerInner:{ maxWidth:'1000px', margin:'0 auto', display:'flex', alignItems:'center', justifyContent:'space-between', padding:'12px 20px' },
  logoutBtn:  { background:'rgba(255,255,255,0.06)', border:'none', color:'#64748B', padding:'6px 12px', borderRadius:'8px', cursor:'pointer', fontSize:'12px', fontFamily:'Heebo,sans-serif' },
  tabs:       { maxWidth:'1000px', margin:'0 auto', display:'flex', padding:'0 20px', gap:'4px' },
  tab:        { padding:'10px 16px', background:'transparent', border:'none', color:'#64748B', fontSize:'13px', fontWeight:'600', cursor:'pointer', borderBottom:'2px solid transparent', fontFamily:'Heebo,sans-serif' },
  tabActive:  { color:'#3B82F6', borderBottom:'2px solid #3B82F6' },
  content:    { maxWidth:'1000px', margin:'0 auto', padding:'20px' },
  statsRow:   { display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:'10px', marginBottom:'20px' },
  statCard:   { background:'#1E293B', borderRadius:'14px', padding:'14px', textAlign:'center', border:'1px solid rgba(255,255,255,0.05)' },
  cols:       { display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:'14px', marginBottom:'20px' },
  col:        { background:'#1E293B', borderRadius:'16px', padding:'14px', border:'1px solid rgba(255,255,255,0.05)', minHeight:'200px' },
  colHeader:  { display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:'12px', paddingBottom:'10px', borderBottom:'1px solid rgba(255,255,255,0.06)' },
  empty:      { color:'#334155', fontSize:'13px', textAlign:'center', padding:'20px 0' },
  newBtn:     { width:'100%', padding:'15px', background:'linear-gradient(135deg,#3B82F6,#8B5CF6)', border:'none', borderRadius:'14px', color:'white', fontSize:'15px', fontWeight:'700', cursor:'pointer', fontFamily:'Heebo,sans-serif' },
  histCard:   { background:'#1E293B', borderRadius:'20px', overflow:'hidden', border:'1px solid rgba(255,255,255,0.05)' },
  histTitle:  { color:'white', fontWeight:'700', padding:'18px 20px', borderBottom:'1px solid rgba(255,255,255,0.05)', fontSize:'15px' },
  histRow:    { padding:'14px 20px', borderBottom:'1px solid rgba(255,255,255,0.04)' },
  histDetail: { color:'#64748B', fontSize:'12px', marginTop:'3px' },
  timesRow:   { display:'flex', gap:'6px', marginTop:'8px', flexWrap:'wrap' },
  statusPill: { padding:'2px 9px', borderRadius:'20px', fontSize:'11px', fontWeight:'600' },
};
